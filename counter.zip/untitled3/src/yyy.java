public class yyy {

    public static void main(String[]args){

    }
}
