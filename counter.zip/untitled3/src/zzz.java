package com.company;

import java.util.Arrays;

public class zzz {

    public static int[][] MassiveList = new int[10][10]; //создание двумерного массива типа int 10х10

    public static void main(String[]args){
        for (int x = 0; x < MassiveList.length; x++){
            for (int y = 0; y < MassiveList[x].length; y++){
                MassiveList[x][y] = x+1;
System.out.print(MassiveList[x][y]);
            }
        }
    }
}
